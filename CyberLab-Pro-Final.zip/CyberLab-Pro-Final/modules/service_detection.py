import ipaddress
import socket


def service_detection():
    print("\n" + "=" * 60)
    print("SERVICE DETECTION")
    print("=" * 60)

    target = input("Enter authorized private/lab IP: ").strip()
    try:
        ip = ipaddress.ip_address(target)
        if not (ip.is_private or ip.is_loopback):
            print("[!] Use a private or loopback lab IP.")
            return
    except ValueError:
        print("[!] Invalid IP.")
        return

    try:
        port = int(input("Enter open TCP port: ").strip())
        if not 1 <= port <= 65535:
            raise ValueError
    except ValueError:
        print("[!] Invalid port.")
        return

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(2)
    try:
        sock.connect((target, port))
        try:
            sock.sendall(b"\r\n")
            banner = sock.recv(1024).decode(errors="ignore").strip()
        except OSError:
            banner = ""

        try:
            service = socket.getservbyport(port, "tcp")
        except OSError:
            service = "Unknown"

        print("\nPort    :", port)
        print("Service :", service)
        print("Banner  :", banner[:200] if banner else "Not available")
    except OSError:
        print("[!] Port is closed or unreachable.")
    finally:
        sock.close()
