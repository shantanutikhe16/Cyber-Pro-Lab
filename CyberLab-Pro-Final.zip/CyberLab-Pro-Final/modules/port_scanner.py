import ipaddress
import socket
from datetime import datetime


COMMON_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP",
    53: "DNS", 80: "HTTP", 110: "POP3", 135: "MSRPC",
    139: "NetBIOS", 143: "IMAP", 443: "HTTPS", 445: "SMB",
    3306: "MySQL", 3389: "RDP", 8080: "HTTP-Proxy",
}


def _authorized_target(target):
    try:
        ip = ipaddress.ip_address(target)
        return ip.is_private or ip.is_loopback
    except ValueError:
        return False


def scan_port(target, port, timeout=0.5):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        return sock.connect_ex((target, port)) == 0
    except OSError:
        return False
    finally:
        sock.close()


def port_scanner():
    print("\n" + "=" * 60)
    print("PORT SCANNER")
    print("=" * 60)
    target = input("Enter authorized private/lab IP: ").strip()

    if not _authorized_target(target):
        print("[!] Use a private or loopback lab IP.")
        return

    opened = []
    for port, service in COMMON_PORTS.items():
        print(f"Checking {port:5} ({service})...", end=" ")
        if scan_port(target, port):
            print("[OPEN]")
            opened.append((port, service))
        else:
            print("[CLOSED]")

    print("\nOpen ports:")
    if opened:
        for port, service in opened:
            print(f"  {port:<6} -> {service}")
    else:
        print("  None detected.")

    print("Completed:", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
