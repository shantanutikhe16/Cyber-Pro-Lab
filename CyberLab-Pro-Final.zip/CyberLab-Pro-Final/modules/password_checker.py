import re


def password_strength_analyzer():
    print("\n" + "=" * 60)
    print("PASSWORD STRENGTH ANALYZER")
    print("=" * 60)
    print("Use a test password; do not enter a real password.")

    password = input("Test password: ")
    score = 0
    suggestions = []

    checks = [
        (len(password) >= 12, "Use at least 12 characters."),
        (bool(re.search(r"[A-Z]", password)), "Add an uppercase letter."),
        (bool(re.search(r"[a-z]", password)), "Add a lowercase letter."),
        (bool(re.search(r"\d", password)), "Add a number."),
        (bool(re.search(r"[^A-Za-z0-9]", password)), "Add a special character."),
    ]

    for passed, message in checks:
        if passed:
            score += 1
        else:
            suggestions.append(message)

    if score <= 2:
        strength = "WEAK"
    elif score <= 4:
        strength = "MEDIUM"
    else:
        strength = "STRONG"

    print(f"\nScore: {score}/5")
    print("Strength:", strength)

    if suggestions:
        print("\nSuggestions:")
        for item in suggestions:
            print("-", item)
