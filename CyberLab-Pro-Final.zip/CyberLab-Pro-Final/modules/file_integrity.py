import hashlib
import json
from pathlib import Path


HASH_FILE = Path("scans/file_hashes.json")


def calculate_hash(filename):
    digest = hashlib.sha256()
    with open(filename, "rb") as file:
        for block in iter(lambda: file.read(4096), b""):
            digest.update(block)
    return digest.hexdigest()


def file_integrity_monitor():
    print("\n" + "=" * 60)
    print("FILE INTEGRITY MONITOR")
    print("=" * 60)

    filename = input("Enter file path to monitor: ").strip()
    path = Path(filename)

    if not path.is_file():
        print("[!] File not found.")
        return

    HASH_FILE.parent.mkdir(exist_ok=True)

    try:
        hashes = json.loads(HASH_FILE.read_text(encoding="utf-8")) if HASH_FILE.exists() else {}
    except json.JSONDecodeError:
        hashes = {}

    current = calculate_hash(path)

    if filename not in hashes:
        hashes[filename] = current
        HASH_FILE.write_text(json.dumps(hashes, indent=4), encoding="utf-8")
        print("[+] Baseline created.")
        print("SHA-256:", current)
        return

    old = hashes[filename]
    print("Stored hash :", old)
    print("Current hash:", current)

    if old == current:
        print("[+] File integrity OK.")
    else:
        print("[!] ALERT: File has changed.")
        if input("Update baseline? (yes/no): ").strip().lower() == "yes":
            hashes[filename] = current
            HASH_FILE.write_text(json.dumps(hashes, indent=4), encoding="utf-8")
            print("[+] Baseline updated.")
