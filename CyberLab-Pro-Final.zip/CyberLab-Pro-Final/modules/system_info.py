import platform
import socket
import psutil


def system_information():
    print("\n" + "=" * 60)
    print("SYSTEM INFORMATION")
    print("=" * 60)
    print("Operating System :", platform.system())
    print("OS Version       :", platform.version())
    print("Architecture     :", platform.machine())
    print("Processor        :", platform.processor())
    print("Hostname         :", socket.gethostname())

    try:
        print("Local IP         :", socket.gethostbyname(socket.gethostname()))
    except socket.error:
        print("Local IP         : Unable to detect")

    print("CPU Usage        :", psutil.cpu_percent(interval=0.5), "%")
    print("RAM Usage        :", psutil.virtual_memory().percent, "%")
    print("Disk Usage       :", psutil.disk_usage("/").percent, "%")
