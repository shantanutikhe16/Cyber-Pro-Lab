from pathlib import Path
from collections import Counter


def security_log_analyzer():
    print("\n" + "=" * 60)
    print("SECURITY LOG ANALYZER")
    print("=" * 60)

    path = Path("logs/security.log")
    if not path.exists():
        print("[!] logs/security.log not found.")
        return

    lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    text = "\n".join(lines).upper()
    counts = Counter()

    for word in ("INFO", "WARNING", "ERROR", "FAILED LOGIN"):
        counts[word] = text.count(word)

    print("\nTotal entries :", len(lines))
    for word in ("INFO", "WARNING", "ERROR", "FAILED LOGIN"):
        print(f"{word:<14}:", counts[word])

    if counts["FAILED LOGIN"] >= 3:
        print("\n[!] ALERT: Multiple failed login events.")
    elif counts["ERROR"] >= 3:
        print("\n[!] WARNING: Multiple errors detected.")
    elif counts["WARNING"] >= 3:
        print("\n[!] WARNING: Multiple warnings detected.")
    else:
        print("\n[+] No major alert detected.")
