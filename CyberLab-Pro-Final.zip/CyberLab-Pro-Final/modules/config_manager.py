import json
from pathlib import Path


CONFIG_FILE = Path("config/config.json")

DEFAULT_CONFIG = {
    "scan_timeout": 0.5,
    "default_ports": [21, 22, 80, 443],
    "log_file": "logs/security.log",
    "report_folder": "reports",
    "scan_folder": "scans",
}


def load_config():
    CONFIG_FILE.parent.mkdir(exist_ok=True)
    if not CONFIG_FILE.exists():
        save_config(DEFAULT_CONFIG)
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return DEFAULT_CONFIG.copy()


def save_config(config):
    CONFIG_FILE.parent.mkdir(exist_ok=True)
    CONFIG_FILE.write_text(
        json.dumps(config, indent=4),
        encoding="utf-8"
    )


def configuration_manager():
    print("\n" + "=" * 60)
    print("CONFIGURATION MANAGER")
    print("=" * 60)

    config = load_config()
    for key, value in config.items():
        print(f"{key}: {value}")

    print("\n1. Reset to defaults")
    print("2. Keep current configuration")
    choice = input("Choice: ").strip()

    if choice == "1":
        save_config(DEFAULT_CONFIG)
        print("[+] Configuration reset.")
    else:
        print("[+] Configuration unchanged.")
