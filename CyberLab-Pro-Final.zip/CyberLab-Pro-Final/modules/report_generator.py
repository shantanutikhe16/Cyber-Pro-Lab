from datetime import datetime
from pathlib import Path


def security_report_generator():
    print("\n" + "=" * 60)
    print("SECURITY REPORT GENERATOR")
    print("=" * 60)

    target = input("Assessment target: ").strip()
    if not target:
        print("[!] Target cannot be empty.")
        return

    findings = []
    print("Enter findings. Type 'done' when finished.")
    while True:
        finding = input("Finding: ").strip()
        if finding.lower() == "done":
            break
        if finding:
            findings.append(finding)

    Path("reports").mkdir(exist_ok=True)
    filename = Path("reports") / (
        "security_report_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".txt"
    )

    with filename.open("w", encoding="utf-8") as report:
        report.write("CYBERLAB PRO SECURITY ASSESSMENT REPORT\n")
        report.write("=" * 60 + "\n")
        report.write(f"Date: {datetime.now():%Y-%m-%d %H:%M:%S}\n")
        report.write(f"Target: {target}\n\n")
        report.write("FINDINGS\n")
        report.write("-" * 60 + "\n")
        for i, finding in enumerate(findings, 1):
            report.write(f"{i}. {finding}\n")
        if not findings:
            report.write("No findings entered.\n")

        report.write("\nRECOMMENDATIONS\n")
        report.write("-" * 60 + "\n")
        report.write("1. Keep operating systems and applications updated.\n")
        report.write("2. Remove or restrict unnecessary network services.\n")
        report.write("3. Use strong passwords and MFA where available.\n")
        report.write("4. Monitor and review security logs.\n")

    print("[+] Report created:", filename)
