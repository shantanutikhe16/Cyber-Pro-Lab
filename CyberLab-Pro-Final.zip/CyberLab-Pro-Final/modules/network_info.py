import socket
import psutil


def network_information():
    print("\n" + "=" * 60)
    print("NETWORK INFORMATION")
    print("=" * 60)
    print("Hostname:", socket.gethostname())

    try:
        print("Primary IP:", socket.gethostbyname(socket.gethostname()))
    except socket.error:
        print("Primary IP: Unable to detect")

    print("\nNetwork Interfaces:")
    for name, addresses in psutil.net_if_addrs().items():
        print(f"\n{name}")
        for addr in addresses:
            if addr.family == socket.AF_INET:
                print("  IPv4 :", addr.address)
                print("  Mask :", addr.netmask)

    stats = psutil.net_io_counters()
    print("\nTraffic")
    print("  Bytes sent    :", stats.bytes_sent)
    print("  Bytes received:", stats.bytes_recv)
