from pathlib import Path
from rich.console import Console
from rich.table import Table


def security_dashboard():
    print("\n" + "=" * 60)
    print("SECURITY DASHBOARD")
    print("=" * 60)

    table = Table(title="CyberLab Pro Status")
    table.add_column("Component")
    table.add_column("Status")

    components = [
        ("Security Logs", Path("logs/security.log").exists()),
        ("Reports Folder", Path("reports").exists()),
        ("Scans Folder", Path("scans").exists()),
        ("Config File", Path("config/config.json").exists()),
    ]

    for name, exists in components:
        table.add_row(name, "READY" if exists else "MISSING")

    Console().print(table)
