import ipaddress


def nmap_scanner():
    print("\n" + "=" * 60)
    print("NMAP SCANNER")
    print("=" * 60)
    print("Use only against an authorized private/loopback lab target.")

    target = input("Enter private/lab IP: ").strip()
    try:
        ip = ipaddress.ip_address(target)
        if not (ip.is_private or ip.is_loopback):
            print("[!] Use a private or loopback lab IP.")
            return
    except ValueError:
        print("[!] Invalid IP.")
        return

    try:
        import nmap
    except ImportError:
        print("[!] Python package missing. Run: py -m pip install python-nmap")
        return

    try:
        scanner = nmap.PortScanner()
        print("[+] Starting Nmap...")
        scanner.scan(target, arguments="-sV --top-ports 20")

        if target not in scanner.all_hosts():
            print("[!] Host is offline or unreachable.")
            return

        print(f"\nHost: {target}")
        print("State:", scanner[target].state())

        for protocol in scanner[target].all_protocols():
            for port in sorted(scanner[target][protocol].keys()):
                data = scanner[target][protocol][port]
                print(
                    f"Port {port}: {data.get('state', 'unknown')} | "
                    f"{data.get('name', 'unknown')} | "
                    f"{data.get('product', '')} {data.get('version', '')}"
                )
    except Exception as exc:
        print("[!] Nmap error:", exc)
