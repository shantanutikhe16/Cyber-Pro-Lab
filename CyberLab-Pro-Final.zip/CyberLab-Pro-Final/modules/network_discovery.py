import ipaddress
import socket


def network_discovery():
    print("\n" + "=" * 60)
    print("NETWORK DISCOVERY")
    print("=" * 60)
    print("Use only an authorized private/lab network.")

    network = input("Enter lab network (example 192.168.1.0/24): ").strip()
    try:
        net = ipaddress.ip_network(network, strict=False)
    except ValueError:
        print("[!] Invalid network.")
        return

    if not (net.is_private or net.is_loopback):
        print("[!] This lab discovery accepts private/loopback networks only.")
        return

    active = []
    for ip in net.hosts():
        host = str(ip)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.15)
        try:
            if sock.connect_ex((host, 80)) == 0:
                active.append(host)
                print("[+] HTTP host:", host)
        except OSError:
            pass
        finally:
            sock.close()

    print(f"\nActive HTTP hosts found: {len(active)}")
    print("Note: this basic method can miss hosts that do not expose TCP/80.")
