# CyberLab Pro
Ethical Hacking & Security Assessment Lab

## Modules
1. System Information
2. Network Information
3. Network Discovery
4. Port Scanner
5. Service Detection
6. Password Strength Analyzer
7. Security Log Analyzer
8. Nmap Scanner
9. Security Report Generator
10. Security Dashboard
11. Configuration Manager
12. Vulnerability Assessment
13. File Integrity Monitor

## Setup
```text
py -m pip install -r requirements.txt
py main.py
```

Nmap module additionally requires the Nmap application installed and available on PATH.

Use scanning and assessment functions only on systems/networks you own or have explicit permission to test.
