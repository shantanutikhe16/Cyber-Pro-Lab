from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from modules.system_info import system_information
from modules.network_info import network_information
from modules.network_discovery import network_discovery
from modules.port_scanner import port_scanner
from modules.service_detection import service_detection
from modules.password_checker import password_strength_analyzer
from modules.log_analyzer import security_log_analyzer
from modules.nmap_scanner import nmap_scanner
from modules.report_generator import security_report_generator
from modules.security_dashboard import security_dashboard
from modules.config_manager import configuration_manager
from modules.vulnerability_assessment import vulnerability_assessment
from modules.file_integrity import file_integrity_monitor

console = Console()


def show_banner():
    console.print(
        Panel.fit(
            "[bold cyan]CYBERLAB PRO[/bold cyan]\n"
            "[yellow]Ethical Hacking & Security Assessment Lab[/yellow]\n"
            "[green]Authorized Security Testing Only[/green]",
            title="🛡 SECURITY LAB",
        )
    )


def show_menu():
    table = Table(title="CyberLab Pro Security Dashboard")
    table.add_column("Option", justify="center", style="cyan", width=8)
    table.add_column("Security Module", style="green")

    items = [
        ("1", "System Information"),
        ("2", "Network Information"),
        ("3", "Network Discovery"),
        ("4", "Port Scanner"),
        ("5", "Service Detection"),
        ("6", "Password Strength Analyzer"),
        ("7", "Security Log Analyzer"),
        ("8", "Nmap Scanner"),
        ("9", "Security Report Generator"),
        ("10", "Security Dashboard"),
        ("11", "Configuration Manager"),
        ("12", "Vulnerability Assessment"),
        ("13", "File Integrity Monitor"),
        ("0", "Exit"),
    ]
    for number, name in items:
        table.add_row(number, name)
    console.print(table)


def main():
    while True:
        console.clear()
        show_banner()
        show_menu()
        choice = console.input("\n[bold cyan]CyberLab > [/bold cyan]").strip()

        if choice == "0":
            console.print("[bold green]CyberLab Pro closed.[/bold green]")
            return

        actions = {
            "1": system_information,
            "2": network_information,
            "3": network_discovery,
            "4": port_scanner,
            "5": service_detection,
            "6": password_strength_analyzer,
            "7": security_log_analyzer,
            "8": nmap_scanner,
            "9": security_report_generator,
            "10": security_dashboard,
            "11": configuration_manager,
            "12": vulnerability_assessment,
            "13": file_integrity_monitor,
        }

        action = actions.get(choice)
        if action is None:
            console.print("[bold red][!] Invalid option.[/bold red]")
        else:
            try:
                action()
            except KeyboardInterrupt:
                console.print("\n[yellow]Operation cancelled.[/yellow]")
            except Exception as exc:
                console.print(f"[bold red][!] Module error: {exc}[/bold red]")

        input("\nPress ENTER to return to the dashboard...")


if __name__ == "__main__":
    main()
